
Licence: This program is licenced under GPL


 In order to install this program You need to do following actions :
 
 a) Unpack this ziped exe file in a directory that you
 want.
 
 b) Place in the same directory the *.ggf files that
 you want to convert.
 
 c) Run the exe file.
 
 After the program is ready, you will get 2 files:
 
 a) GGS.JOU: This file contains the informations about
 the players

 b) GGS.WTB: The actual game database 
 

Known problems:
The converted games are not perfectly solved at 22 plies.
So the theoretical score is always the real score :)
